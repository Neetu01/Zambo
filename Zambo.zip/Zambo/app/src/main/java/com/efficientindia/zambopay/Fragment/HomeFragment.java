package com.efficientindia.zambopay.Fragment;

import android.Manifest;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.efficientindia.zambopay.Adapter.MenuItemHomeAdapter;
import com.efficientindia.zambopay.Adapter.Recycleradapterrecharge;
import com.efficientindia.zambopay.Model.Griditem;
import com.efficientindia.zambopay.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by aftab on 6/6/2018.
 */
//@RequiresApi(api = Build.VERSION_CODES.KITKAT)

public class HomeFragment extends Fragment implements View.OnClickListener, AdapterView.OnItemClickListener {

    private static final int INTENT_CODE = 1;
    private CardView cardViewAeps,cardViewMoney,cardViewMobile,cardViewDth,cardViewDatacard,
            cardViewElectricity,cardViewGas,cardViewLandline,cardViewInsuarance,cardViewAeps2;
    ProgressDialog progressDialog;
    static String phone = "",roundMobile = "",roundPassword = "";
    private static final int REQUEST_PERMISSIONS = 1;
    private static String[] PERMISSIONS = {Manifest.permission.READ_PHONE_STATE
            , Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION};
    public TextView android;
    String transType;
    LinearLayout lnAeps,lnMoney2,lnRecharge3,lnBbps;

    GridView gridViewRechargeThree,billpaymentview,othersview;
    CardView cardViewCustomer,cardViewBbps,cardViewRechargeThree,cardViewMoneytransferTwo,cardViewRechargeTwo;

    public String[] nameItem={"Mobile Prepaid","Mobile Postpaid ","DTH","Broadband",
            "Electricity","Landline","Gas","Water","Credit Card","Insurance"};

    public Integer[] mThumbIds = {
            R.drawable.mobilepre,R.drawable.mpostpaid,R.drawable.dth,
            R.drawable.broadbandcolor,R.drawable.electricitycolor,R.drawable.landline,
            R.drawable.gas,R.drawable.watericon,R.drawable.creditcardcolor,
            R.drawable.insurance,};

    public String[] billtext={"Gas Bill","Insurance","Water Bill","Landline","Credit Card","Broadband","Electricity","Data Card"};

    public Integer[] billicons={R.drawable.gas,R.drawable.insurance,R.drawable.water,R.drawable.landline,R.drawable.credit_card,R.drawable.broadband,R.drawable.electricity,R.drawable.datacard};

    public String[] text={"Prepaid","Postpaid","DTH"};

    public Integer[] icons={R.drawable.mobile,R.drawable.postpaid,R.drawable.dth};
    RecyclerView.Adapter recylerviewadapter;
    public String[] otext={"Transactions"};
    public Integer[] oicons={R.drawable.mobile};
    Animation animationup,animationdown;
    RecyclerView recyclerView;

    @Override
    public View onCreateView( LayoutInflater inflater,  ViewGroup container,  Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);



        animationup= AnimationUtils.loadAnimation(getActivity(),R.anim.slide_up);
        animationdown=AnimationUtils.loadAnimation(getActivity(),R.anim.slide_down);


        /*recharge*/
        gridViewRechargeThree=view.findViewById(R.id.recharge);
        MenuItemHomeAdapter recharge = new MenuItemHomeAdapter(getActivity(),text,icons);
        gridViewRechargeThree.setAdapter(recharge);
        /*billpayment*/
        billpaymentview=view.findViewById(R.id.billpayment);
        MenuItemHomeAdapter billpayment=new MenuItemHomeAdapter(getActivity(),billtext,billicons);
        billpaymentview.setAdapter(billpayment);
        /*more services*/
        othersview=view.findViewById(R.id.othersimg);
        MenuItemHomeAdapter menuothersview=new MenuItemHomeAdapter(getActivity(),otext,oicons);
        othersview.setAdapter(menuothersview);
        return view;

    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
    }
}
