package com.efficientindia.zambopay.Activity;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetDialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import com.efficientindia.zambopay.Adapter.MenuBottomSheetAdapter;
import com.efficientindia.zambopay.R;

public class BottomSheet extends BottomSheetDialogFragment implements View.OnClickListener, AdapterView.OnItemClickListener {

    public Integer[] mThumbIds = {
            R.drawable.mobile,R.drawable.postpaid,R.drawable.dth,
            R.drawable.broadband,R.drawable.electricity,R.drawable.landline,
            R.drawable.gas,R.drawable.water,R.drawable.credit_card,
            R.drawable.insurance,};

    public String[] nameItem={"Prepaid","Postpaid ","DTH","Broadband",
            "Electricity","Landline","Gas","Water","Credit Card","Insurance"};

    GridView gridViewRechargeThree;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.activity_bottom_sheet, container, false);
        gridViewRechargeThree=view.findViewById(R.id.gridview_recharge_three);
        MenuBottomSheetAdapter adapter = new MenuBottomSheetAdapter(getActivity(),nameItem,mThumbIds);
        gridViewRechargeThree.setAdapter(adapter);
        gridViewRechargeThree.setOnItemClickListener(this);
        return view;
    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }
}
