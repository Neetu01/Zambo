package com.efficientindia.zambopay.Adapter;

/**
 * Created by aftab on 6/7/2018.
 */

public class PagerAdapterTab {
}
